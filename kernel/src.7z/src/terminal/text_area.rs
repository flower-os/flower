// TODO
use super::*;

// TODO
// - Tests
// - Make area.cursor local to area
// - Writer vs area in with state
// - With state is confusing
// - Fix backspacing

// TODO future self - clear top lines as well otherwise bad things... also bottom line

/// A sized terminal text area.
// As a general hint to people writing implementations for [TextArea], it's ok to use the color and
// cursor fields directly, but to set them its better to use the setters since they check if
// everything is valid. Panic if its expected that it is valid -- it's better than leaving it in an
// invalid state.
pub struct TextArea<'w, 'b, E: Debug, T: TerminalOutput<E> + 'w> {
    writer: &'w RwLock<T>,
    /// The bottom left of the text area, which is ga valid point to write to
    bottom_left: Point,
    /// The top right of the text area, which is a valid point to write to
    top_right: Point,
    resolution: Resolution,
    buffer: &'b mut [&'b mut [TerminalCharacter]],
    /// The area's cursor. Global, not relative to origin
    cursor: Point,
    color: ColorPair,
    _phantom: PhantomData<E>,
}

/// An error returned from [TextArea.new] if one of the points is out of bounds
#[derive(Debug)]
pub enum InvalidParameters {
    OriginOutOfBounds(Point),
    /// If the size is too large such that the top right would be out of bounds
    TopRightOutOfBounds(Point),
}

impl<'w, 'b, E: Debug, T: TerminalOutput<E> + 'w> TextArea<'w, 'b, E, T> {
    /// Creates a new TextArea with a writer RwLock for the terminal to write to and the given bounds
    ///
    /// # Note
    ///
    /// At the moment, it is required that the user passes in a buffer of the same size as the
    /// resolution. When const-generics is implemented in nightly, it will be able to create its own
    /// buffer.
    pub fn new(
              writer: &'w RwLock<T>,
              bottom_left: Point,
              size: Resolution,
              buffer: &'b mut [&'b mut [TerminalCharacter]]
    ) -> Result<Self, InvalidParameters> {

        let top_right = Point {
            x: bottom_left.x + size.x - 1,
            y: bottom_left.y + size.y - 1,
        };

        {
            let writer = writer.read();

            if !writer.in_bounds(bottom_left) {
                return Err(InvalidParameters::OriginOutOfBounds(bottom_left));
            }

            if !writer.in_bounds(top_right) {
                return Err(InvalidParameters::TopRightOutOfBounds(top_right));
            }
        }

        Ok(TextArea {
            writer,
            bottom_left,
            top_right,
            resolution: size,
            buffer,
            cursor: Point {
                x: bottom_left.x,
                y: top_right.y
            },
            color: color!(White on Black),
            _phantom: PhantomData,
        })
    }

    // TODO not thread safe but it's fine since we don't have threads
    // Underlying writer could be modified while in with_state
    /// Preserves the state of the underlying writer, letting the area write to it with no fear of
    /// having to set it back again.
    ///
    /// # Side Effects
    ///
    /// This function locks the underlying writer to make sure that it isn't resized while it has an
    /// old state stored so that there isn't an error setting it back to the old state. Use the
    /// second argument of the closure to access the writer.
    ///
    /// # Closure arguments
    ///
    /// 1. The text area. Required to fix borrowing
    /// 2. The locked underlying writer. See side effects.
    ///
    /// # What It Does
    /// Sets the cursor pos and color of the underlying writer to the area's, executes the closure,
    /// and then sets the underlying writer's cursor and color and the area's cursor and color back
    /// to what it was
    fn with_state<F, R>(&mut self, f: F) -> Result<R, TerminalOutputError<E>>
        where F: FnOnce(&mut Self) -> Result<R, TerminalOutputError<E>>
    {

        // Store old state
        let old_writer_state = (
            self.writer.read().cursor_pos(),
            self.writer.read().color()
        );
        let old_area_state = (self.cursor, self.color);

        // Sync state
        // Scope because temp variables
        self.writer.write().set_cursor_pos(self.cursor)
            .expect("Cursor in bounds of TextArea should be in bounds of underlying writer");

        self.writer.write().set_color(self.color)
            .expect("Color supported by TextArea should be supported by underlying writer");

        let ret = f(self);

        // Reset state
        self.writer.write().set_cursor_pos(old_writer_state.0)
            .expect("Old writer cursor position should still be in bounds");
        self.writer.write().set_color(old_writer_state.1)
            .expect("Old writer color should still be supported");

        self.set_cursor_pos(old_area_state.0)
            .expect("Old area cursor position should still be in bounds");
        self.set_color(old_area_state.1)
            .expect("Old area color should still be supported");

        ret
    }

    /// Preserves the state of the underlying writer, letting the area write to it with no fear of
    /// having to set it back again. Writes changes back to the area.
    ///
    /// # Side Effects
    ///
    /// This function locks the underlying writer to make sure that it isn't resized while it has an
    /// old state stored so that there isn't an error setting it back to the old state. Use the
    /// second argument of the closure to access the writer.
    ///
    /// # Closure arguments
    ///
    /// 1. The text area. Required to fix borrowing
    /// 2. The locked underlying writer. It's locked for internal reasons by the function
    ///
    /// # What It Does
    ///
    /// Sets the cursor pos and color of the underlying writer to the area's, executes the closure,
    /// sets the area's cursor and color to the writer's cursor and color, and then sets the
    /// underlying writer's position back to what it was.
    ///
    /// # Note
    ///
    fn with_state_writeback<F, R>(&mut self, f: F) -> Result<R, TerminalOutputError<E>>
        where F: FnOnce(&mut Self) -> Result<R, TerminalOutputError<E>>
    {
        // Store old state
        let old_writer_state = (
            self.writer.read().cursor_pos(), self.writer.read().color()
        );

        // Sync state
        self.writer.write().set_cursor_pos(self.cursor)
            .expect("Cursor in bounds of TextArea should be in bounds of underlying writer");
        self.writer.write().set_color(self.color)
            .expect("Color supported by TextArea should be supported by underlying writer");

        let ret = f(self);

        // Write back state
        self.set_cursor_pos(self.writer.read().cursor_pos())?;
        self.set_color(self.writer.read().color())
            .expect("Color valid for writer should be valid for area");

        // Reset state
        self.writer.write().set_cursor_pos(old_writer_state.0)
            .expect("Old writer cursor position should still be in bounds");
        self.writer.write().set_color(old_writer_state.1).expect("Old writer color should still be supported");

        ret
    }

    /// Repaints the text area according to its internal buffer. This will overwrite any accidental
    /// changes made to the buffer, e.g by setting characters inside the text area using the containing
    /// terminal
    pub fn repaint(&mut self) -> Result<(), TerminalOutputError<E>> {
        // If cursor is at bottom right set directly so the terminal doesn't wrap
        let bottom_right = Point::new(self.bottom_left.x, self.top_right.y);

        if self.buffer[0][0].character == 'a' { // TODO
            panic!("A in 0,0 wat");
        }

        self.with_state(|area| {
            area.writer.set_cursor_pos(area.bottom_left)
                .expect("Bottom left should be in bounds of text area");

            for (y, line) in area.buffer.iter().enumerate() {
                for (x, character) in line.iter().enumerate() {
                    if area.writer.read().cursor_pos() == bottom_right {
                        area.writer.write().set_char(*character, bottom_right)?;
                    } else {
                        area.writer.write().write_colored(character.character, character.color)?;
                    }
                }

                area.writer.write()
                    .set_cursor_pos(Point::new(area.bottom_left.x, area.cursor_pos().y + 1))
                    .expect("Position inside repaint should be correct");
            }

            Ok(())
        })?;

        Ok(())
    }

    /// Converts a global cursor to a local cursor
    fn cursor_to_local(&self, cursor: Point) -> Point {
        Point {
            x: cursor.x - self.bottom_left.x,
            y: cursor.y - self.bottom_left.y,
        }
    }
}

impl<'w, 'b, E: Debug, T: TerminalOutput<E> + 'w> TerminalOutput<E> for TextArea<'w, 'b, E, T> {
    fn color_supported(&self, color: Color) -> bool {
        self.writer.read().color_supported(color)
    }

    fn resolution(&self) -> Resolution {
        self.resolution
    }

    fn in_bounds(&self, point: Point) -> bool {
        point.x >= self.bottom_left.x &&
            point.y >= self.bottom_left.y &&
            point.x <= self.top_right.x &&
            point.y <= self.top_right.y
    }

    fn set_cursor_pos(&mut self, point: Point) -> Result<(), TerminalOutputError<E>> {
        if self.in_bounds(point) {
            self.cursor = point;
            Ok(())
        } else {
            Err(TerminalOutputError::OutOfBounds(point))
        }
    }

    fn cursor_pos(&self) -> Point {
        self.cursor
    }

    fn color(&self) -> ColorPair {
        self.color
    }

    fn set_color(&mut self, color: ColorPair) -> Result<(), TerminalOutputError<E>> {
        if !self.color_supported(color.background) {
            return Err(TerminalOutputError::ColorUnsupported(color.background));
        }

        if !self.color_supported(color.foreground) {
            return Err(TerminalOutputError::ColorUnsupported(color.foreground));
        }

        self.color = color;
        Ok(())
    }

    fn set_char(&mut self, character: TerminalCharacter, point: Point) -> Result<(), TerminalOutputError<E>> {
        if self.in_bounds(point) {
            self.buffer[point.y][point.x] = character;
            self.writer.write().set_char(character, point)
        } else {
            Err(TerminalOutputError::OutOfBounds(point))
        }
    }

    fn write_colored(&mut self, character: char, color: ColorPair) -> Result<(), TerminalOutputError<E>> {
        match character {
            '\n' => self.new_line(),
            _ => {
                self.with_state_writeback(|area| {
                    area.writer.write().write_colored(character, color)?;
                    area.buffer[area.cursor.y][area.cursor.x] = TerminalCharacter::new(character, color);

                    // If cursor is out of bounds, wrap
                    if !area.in_bounds(area.writer.read().cursor_pos()) {
                        area.new_line()?;
                        area.writer.write().set_cursor_pos(area.cursor_pos())?;
                    }

                    Ok(())
                })
            }
        }
    }

    // Implemented for performance
    fn write_string_colored(&mut self, str: &str, color: ColorPair) -> Result<(), TerminalOutputError<E>> {
        self.with_state_writeback(|area| {
            for character in str.chars() {
                // We don't call TextArea.write_colored because writer is locked by with_state_writeback
                // already

                let terminal_character = TerminalCharacter { character, color };
                area.writer.write().write_colored(character, color)?;

                let local_pos = area.cursor_to_local(area.cursor);

                // Don't add \n's to the buffer
                if character != '\n' {
                    area.buffer[local_pos.y][local_pos.x] = terminal_character;
                }

                // If cursor is out of bounds, wrap
                if !area.in_bounds(area.writer.read().cursor_pos()) {
                    area.new_line()?;
                    area.writer.write().set_cursor_pos(area.cursor_pos())?;
                } else {
                    area.set_cursor_pos(area.writer.read().cursor_pos())
                        .expect("Point should be valid");
                }
            }

            Ok(())
        })
    }

    fn clear_line(&mut self, y: usize) -> Result<(), TerminalOutputError<E>> {
        self.with_state(|area| {
            area.set_cursor_pos(Point::new(area.bottom_left.x, y))?;

            for _ in area.bottom_left.x..=area.top_right.x {
                area.writer.write().write(' ')?;

                let local_pos = area.cursor_to_local(area.cursor_pos());

                area.buffer[local_pos.y][local_pos.x] = TerminalCharacter::new(
                    ' ',
                    area.color()
                );
            }

            Ok(())
        })
    }

    fn clear(&mut self) -> Result<(), TerminalOutputError<E>> {
        for y in self.bottom_left.y..=self.top_right.y {
            self.clear_line(y)?;
        }

        Ok(())
    }

    fn scroll_down(&mut self, lines: usize) -> Result<(), TerminalOutputError<E>> {
        if lines == 0 { // Nothing to scroll
            return Ok(());
        }

        self.set_cursor_pos(Point::new(self.bottom_left.x, self.top_right.y))
            .expect("Min point should not be out of bounds");

        // Shift lines right (up) by amount only if amount < Y resolution
        // If amount is any more then the data will be cleared anyway
        if lines < self.resolution.y {
            self.buffer.rotate_right(lines); // Rotate right, not left like default
        }

        // Repaint
        self.repaint()?;

        // Clear top lines
        for line_no in self.top_right.y .. self.top_right.y - lines {
            self.clear_line(line_no)?;
        }

        // Clear bottom line
        self.clear_line(0)?;

        Ok(())
    }

    fn new_line(&mut self) -> Result<(), TerminalOutputError<E>> {
        if self.cursor.y > self.bottom_left.y {
            self.set_cursor_pos(Point::new(self.bottom_left.x, self.cursor.y - 1))
        } else {
            self.scroll_down(1)
        }
    }

    fn backspace(&mut self) -> Result<(), TerminalOutputError<E>> {
        unimplemented!()
    }
}
