#![no_std]

#![feature(asm)]
#![feature(lang_items)]
#![feature(const_fn)]
#![feature(unique, const_unique_new)]
#![feature(slice_rotate)]
#![feature(try_from)]
#![feature(nll)]
#![feature(inclusive_range_syntax)]

extern crate rlibc;
extern crate volatile;
extern crate spin;
extern crate x86_64;
extern crate array_init; // Used as a workaround until const-generics arrives

#[macro_use]
extern crate bitflags;

#[macro_use]
extern crate lazy_static;

mod lang;
#[macro_use]
mod util;
#[macro_use]
mod color;
mod io;
#[macro_use]
mod terminal;
mod drivers;

use drivers::{vga, ps2};
use terminal::{TerminalOutput, TerminalCharacter, Resolution};
use util::halt;

/// Kernel main function
#[no_mangle]
pub extern fn kmain() -> ! {

    terminal::STDOUT.write().clear().expect("Screen clear failed");
    print_flower().expect("Flower print failed");

    terminal::STDOUT.write().set_color(color!(Green on Black))
        .expect("Color should be supported");

    // Print boot message
    // TODO own text area
    println!("Flower kernel boot!");
    println!("-------------------\n");

    // Reset colors
    terminal::STDOUT.write().set_color(color!(White on Black))
        .expect("Color should be supported");

    ps2::CONTROLLER.lock().initialize().expect("PS/2 should successfully initialize");

    halt()
}

fn print_flower() -> Result<(), terminal::TerminalOutputError<()>> {
    const FLOWER: &'static str = include_str!("resources/art/flower.txt");
    const FLOWER_STEM: &'static str = include_str!("resources/art/flower_stem.txt");
    const SIZE: Resolution = Resolution::new(47, 25);

    // ~*~* Entering unsafe hack... *~*~
    // Unsafe magic to make the array of arrays into an array of slices
    // Thanks to matklad (github usr) and nvzqz (github usr)
    // This whole solution in general is just one giant hack until we get const generics

    let mut array_of_arrays = array_init::array_init::<[_; SIZE.y], _>(
        |_| [
            TerminalCharacter::new(' ', color!(Black on Black)); SIZE.x
        ]
    );

    let mut buf: [&mut [TerminalCharacter]; SIZE.y] = unsafe { core::mem::uninitialized() };

    for (slot, array) in buf.iter_mut().zip(&mut array_of_arrays) {
        unsafe { core::ptr::write(slot, array); }
    }

    // ~*~* Exiting unsafe hack... *~*~

    let mut area = terminal::TextArea::new(
        &vga::WRITER,
        terminal::Point::new(32, 0),
        SIZE,
        &mut buf
    ).expect("Parameters should be valid");

    area.write_string("aaa
bbb
ccc
ddd
eee
fff
ggg
hhh
iii
jjj
kkk
lll
mmm
nnn
ooo
ppp
qqq
rrr
sss
ttt
uuu
vvv
www")?;
area.repaint()
//Ok(())
//    area.write_string("Hello!\nHello2!\n")?;
//    area.write_string_colored(FLOWER, color!(LightBlue on Black))?;
//    area.write_string_colored(FLOWER_STEM, color!(Green on Black))?;
//    area.write_string("Hello!3!\n")
}
